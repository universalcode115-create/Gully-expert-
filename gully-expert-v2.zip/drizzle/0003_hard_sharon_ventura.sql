ALTER TABLE `partner_profiles` MODIFY COLUMN `isVerified` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `partner_profiles` MODIFY COLUMN `isOnline` int NOT NULL DEFAULT 0;--> statement-breakpoint
ALTER TABLE `partner_profiles` MODIFY COLUMN `ratingAvg` varchar(10) NOT NULL DEFAULT '0.0';--> statement-breakpoint
ALTER TABLE `partner_profiles` MODIFY COLUMN `reviewCount` int NOT NULL DEFAULT 0;