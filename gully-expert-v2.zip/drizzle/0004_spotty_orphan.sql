CREATE TABLE `services` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`slug` varchar(120) NOT NULL,
	`label` varchar(120) NOT NULL,
	`iconKey` varchar(50) NOT NULL,
	`isActive` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `services_id` PRIMARY KEY(`id`),
	CONSTRAINT `services_name_unique` UNIQUE(`name`),
	CONSTRAINT `services_slug_unique` UNIQUE(`slug`)
);
--> statement-breakpoint
ALTER TABLE `job_posts` ADD `serviceId` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `partner_profiles` ADD `serviceId` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `partner_profiles` ADD `phone` varchar(50);--> statement-breakpoint
ALTER TABLE `reviews` ADD `jobId` int NOT NULL;--> statement-breakpoint
ALTER TABLE `reviews` ADD CONSTRAINT `reviews_jobId_unique` UNIQUE(`jobId`);