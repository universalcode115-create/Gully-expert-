CREATE TABLE `job_posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`customerName` varchar(255) NOT NULL,
	`customerPhone` varchar(50) NOT NULL,
	`category` varchar(100) NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`location` varchar(255) NOT NULL,
	`budget` varchar(100) NOT NULL,
	`status` enum('open','assigned','completed','cancelled') NOT NULL DEFAULT 'open',
	`assignedPartnerId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `job_posts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `partner_profiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`fullName` varchar(255) NOT NULL,
	`category` varchar(100) NOT NULL,
	`bio` text,
	`experienceYears` int NOT NULL DEFAULT 1,
	`basePrice` int NOT NULL DEFAULT 500,
	`serviceRadiusKm` int NOT NULL DEFAULT 5,
	`locationName` varchar(255) NOT NULL DEFAULT 'New Delhi, India',
	`latitude` varchar(50) DEFAULT '28.6139',
	`longitude` varchar(50) DEFAULT '77.2090',
	`photoUrl` text,
	`pastWorkPhotos` text,
	`isVerified` int NOT NULL DEFAULT 1,
	`isOnline` int NOT NULL DEFAULT 1,
	`ratingAvg` varchar(10) NOT NULL DEFAULT '4.8',
	`reviewCount` int NOT NULL DEFAULT 12,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `partner_profiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `partner_profiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `reviews` (
	`id` int AUTO_INCREMENT NOT NULL,
	`partnerId` int NOT NULL,
	`customerId` int NOT NULL,
	`customerName` varchar(255) NOT NULL,
	`rating` int NOT NULL,
	`comment` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reviews_id` PRIMARY KEY(`id`)
);
