import { useEffect, useMemo, useRef, useState } from "react";
import { startLogin } from "@/const";
import { useAuth } from "@/_core/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Bell,
  BriefcaseBusiness,
  CalendarDays,
  CheckCircle2,
  ChevronRight,
  Clock3,
  Compass,
  GraduationCap,
  Hammer,
  Home as HomeIcon,
  Loader2,
  LogOut,
  MapPin,
  Menu,
  MessageCircle,
  Phone,
  Plus,
  Scissors,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  SlidersHorizontal,
  Sparkles,
  Star,
  UserRound,
  Wind,
  Wrench,
  X,
  Zap,
  ClipboardList,
} from "lucide-react";

type Provider = {
  id: number;
  userId: number;
  serviceId: number;
  fullName: string;
  category: string;
  bio: string | null;
  experienceYears: number;
  basePrice: number;
  serviceRadiusKm: number;
  locationName: string;
  phone: string | null;
  latitude: string | null;
  longitude: string | null;
  photoUrl: string | null;
  pastWorkPhotos: string | null;
  isVerified: number;
  isOnline: number;
  ratingAvg: string;
  reviewCount: number;
  createdAt: Date;
  updatedAt: Date;
  distanceKm?: number | null;
};

const CATEGORIES = [
  { name: "All services", label: "All services", icon: Compass, accent: "sand" },
  { name: "Plumber", label: "Plumbing", icon: Wrench, accent: "blue" },
  { name: "Electrician", label: "Electrical", icon: Zap, accent: "amber" },
  { name: "Home Salon", label: "Home salon", icon: Scissors, accent: "rose" },
  { name: "Tutor", label: "Tutoring", icon: GraduationCap, accent: "violet" },
  { name: "AC Repair", label: "AC repair", icon: Wind, accent: "mint" },
  { name: "Carpenter", label: "Carpentry", icon: Hammer, accent: "orange" },
];

const accentStyles: Record<string, string> = {
  sand: "bg-[#f8f0e6] text-[#8c5b2f]",
  blue: "bg-[#e9f3f7] text-[#2b7084]",
  amber: "bg-[#fff4d8] text-[#9a6b00]",
  rose: "bg-[#fae8e8] text-[#a34b56]",
  violet: "bg-[#eeeafd] text-[#6557a8]",
  mint: "bg-[#e1f3ec] text-[#3c806a]",
  orange: "bg-[#fff0e2] text-[#b5652d]",
};

type RoleChoice = "customer" | "service_partner";
const formatINR = (value: number) => `₹${new Intl.NumberFormat("en-IN").format(value)}`;

function ProviderAvatar({ provider, large = false }: { provider: Provider; large?: boolean }) {
  const initials = provider.fullName
    .split(" ")
    .map((part: string) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  if (provider.photoUrl) {
    return <img src={provider.photoUrl} alt={provider.fullName} className={`${large ? "h-28 w-28" : "h-16 w-16"} rounded-2xl object-cover`} />;
  }
  return (
    <div className={`${large ? "h-28 w-28 text-3xl" : "h-16 w-16 text-lg"} flex items-center justify-center rounded-2xl bg-[#164854] font-semibold text-white`}>
      {initials || <UserRound />}
    </div>
  );
}

function Header({ onLogin, onDashboard, onPostJob, authenticated, userName, onLogout }: { onLogin: (role?: RoleChoice) => void; onDashboard: () => void; onPostJob: () => void; authenticated: boolean; userName?: string | null; onLogout: () => void }) {
  const [mobileOpen, setMobileOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-[#e7e2db]/80 bg-[#fbfaf7]/90 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
        <a href="#top" className="flex items-center gap-3" aria-label="GullyExpert home">
          <span className="brand-mark"><MapPin className="h-5 w-5" strokeWidth={2.5} /></span>
          <span className="text-lg font-semibold tracking-[-0.03em] text-[#173e49]">Gully<span className="text-[#d26c3b]">Expert</span></span>
        </a>
        <nav className="hidden items-center gap-8 text-sm font-medium text-[#5c686c] md:flex">
          <a href="#services" className="transition-colors hover:text-[#173e49]">Explore services</a>
          <a href="#how-it-works" className="transition-colors hover:text-[#173e49]">How it works</a>
          <button type="button" className="transition-colors hover:text-[#173e49]" onClick={() => onLogin("service_partner")}>Become a partner</button>
        </nav>
        <div className="hidden items-center gap-3 md:flex">
          {authenticated ? (
            <>
              <Button variant="ghost" className="gap-2 text-[#173e49]" onClick={onDashboard}><UserRound className="h-4 w-4" /> {userName || "My space"}</Button>
              <Button variant="outline" className="rounded-full border-[#d7d0c8] bg-white" onClick={onLogout}><LogOut className="mr-2 h-4 w-4" /> Sign out</Button>
            </>
          ) : (
            <>
              <Button variant="ghost" className="text-[#173e49]" onClick={() => onLogin("customer")}>Sign in</Button>
              <Button className="rounded-full bg-[#173e49] px-5 text-white shadow-lg shadow-[#173e49]/15 hover:bg-[#245b67]" onClick={onPostJob}>Post a request <ArrowUpRight className="ml-2 h-4 w-4" /></Button>
            </>
          )}
        </div>
        <button type="button" className="rounded-full p-2 text-[#173e49] md:hidden" onClick={() => setMobileOpen(!mobileOpen)} aria-label="Toggle menu">
          {mobileOpen ? <X /> : <Menu />}
        </button>
      </div>
      {mobileOpen && (
        <div className="border-t border-[#e7e2db] bg-[#fbfaf7] px-5 py-5 md:hidden">
          <div className="grid gap-3 text-sm font-medium text-[#5c686c]">
            <a href="#services" onClick={() => setMobileOpen(false)}>Explore services</a>
            <a href="#how-it-works" onClick={() => setMobileOpen(false)}>How it works</a>
            <button className="text-left" onClick={() => { setMobileOpen(false); onLogin("service_partner"); }}>Become a partner</button>
            <Separator />
            {authenticated ? <Button variant="outline" onClick={onDashboard}>Open my space</Button> : <Button onClick={() => onLogin("customer")}>Sign in</Button>}
          </div>
        </div>
      )}
    </header>
  );
}

function AuthDialog({ open, onOpenChange, selectedRole, onSelectedRole, onContinue }: { open: boolean; onOpenChange: (open: boolean) => void; selectedRole: RoleChoice; onSelectedRole: (role: RoleChoice) => void; onContinue: () => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg border-[#e2ddd5] bg-[#fbfaf7] p-7 sm:rounded-3xl">
        <DialogHeader>
          <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-2xl bg-[#d8ece7] text-[#173e49]"><ShieldCheck className="h-6 w-6" /></div>
          <DialogTitle className="font-display text-3xl text-[#173e49]">Welcome to your local network</DialogTitle>
          <DialogDescription className="pt-2 text-[#667174]">Sign in securely through Manus OAuth, then choose how you would like to use GullyExpert.</DialogDescription>
        </DialogHeader>
        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <button type="button" onClick={() => onSelectedRole("customer")} className={`role-card ${selectedRole === "customer" ? "role-card-active" : ""}`}>
            <HomeIcon className="h-6 w-6" /><span><strong>Customer</strong><small>Find trusted help nearby</small></span>
          </button>
          <button type="button" onClick={() => onSelectedRole("service_partner")} className={`role-card ${selectedRole === "service_partner" ? "role-card-active" : ""}`}>
            <BriefcaseBusiness className="h-6 w-6" /><span><strong>Service Partner</strong><small>Grow your local business</small></span>
          </button>
        </div>
        <DialogFooter className="mt-6 flex-col gap-3 sm:flex-col">
          <Button className="h-12 w-full rounded-xl bg-[#d26c3b] text-white hover:bg-[#bb582b]" onClick={onContinue}>Continue with Manus OAuth <ArrowRight className="ml-2 h-4 w-4" /></Button>
          <p className="text-center text-xs text-[#8a9292]">You can change your marketplace role later from your account.</p>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ProviderCard({ provider, onOpen }: { provider: Provider; onOpen: () => void }) {
  return (
    <Card className="group overflow-hidden rounded-3xl border-[#e6e0d8] bg-white/80 shadow-[0_16px_50px_rgba(28,54,61,0.05)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_24px_60px_rgba(28,54,61,0.12)]">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-4"><ProviderAvatar provider={provider} /><div><div className="mb-1 flex items-center gap-2"><h3 className="font-display text-xl text-[#173e49]">{provider.fullName}</h3>{provider.isVerified === 1 && <BadgeCheck className="h-4 w-4 text-[#2a8a76]" />}</div><p className="text-sm text-[#738083]">{provider.category}</p></div></div>
          <span className={`availability-dot ${provider.isOnline === 1 ? "availability-online" : "availability-offline"}`} aria-label={provider.isOnline === 1 ? "Online" : "Offline"} />
        </div>
        <div className="mt-5 grid grid-cols-3 gap-2 rounded-2xl bg-[#f7f5f1] p-3 text-center">
          <div><p className="text-sm font-semibold text-[#173e49]">{provider.ratingAvg}</p><p className="text-[11px] uppercase tracking-[0.12em] text-[#899293]">rating</p></div>
          <div><p className="text-sm font-semibold text-[#173e49]">{provider.experienceYears} yrs</p><p className="text-[11px] uppercase tracking-[0.12em] text-[#899293]">experience</p></div>
          <div><p className="text-sm font-semibold text-[#173e49]">{formatINR(provider.basePrice)}</p><p className="text-[11px] uppercase tracking-[0.12em] text-[#899293]">from</p></div>
        </div>
        <div className="mt-4 flex items-center justify-between gap-3 text-sm text-[#6e7b7e]"><span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5" /> {provider.distanceKm !== undefined && provider.distanceKm !== null ? `${provider.distanceKm.toFixed(1)} km away` : provider.locationName}</span><span className="flex items-center gap-1.5"><Star className="h-3.5 w-3.5 fill-[#e5a63d] text-[#e5a63d]" /> {provider.reviewCount} reviews</span></div>
        <div className="mt-5 flex gap-2"><Button onClick={onOpen} variant="outline" className="h-11 flex-1 rounded-xl border-[#d9e0de] text-[#173e49] group-hover:border-[#2a8a76] group-hover:bg-[#eef7f3]">Quick view <ChevronRight className="ml-2 h-4 w-4" /></Button><Button onClick={() => { window.location.href = `/providers/${provider.id}`; }} className="h-11 rounded-xl bg-[#173e49] px-3 text-white hover:bg-[#245b67]" aria-label={`Open ${provider.fullName} profile`}><ArrowUpRight className="h-4 w-4" /></Button></div>
      </CardContent>
    </Card>
  );
}

function ProviderDialog({ provider, open, onOpenChange, onRequest }: { provider: Provider | null; open: boolean; onOpenChange: (open: boolean) => void; onRequest: () => void }) {
  const reviewInput = useMemo(() => ({ partnerId: provider?.id ?? 0 }), [provider?.id]);
  const { data: reviews = [], isLoading } = trpc.providers.reviews.useQuery(reviewInput, { enabled: Boolean(provider) });
  const photos = provider?.pastWorkPhotos ? JSON.parse(provider.pastWorkPhotos) as string[] : [];
  if (!provider) return null;
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] max-w-3xl overflow-y-auto border-[#e2ddd5] bg-[#fbfaf7] p-0 sm:rounded-3xl">
        <div className="relative overflow-hidden rounded-t-3xl bg-[#173e49] p-7 text-white sm:p-9">
          <div className="absolute right-0 top-0 h-48 w-48 rounded-full bg-[#d26c3b]/30 blur-3xl" />
          <div className="relative flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div className="flex items-end gap-4"><ProviderAvatar provider={provider} large /><div><div className="mb-2 flex items-center gap-2"><h2 className="font-display text-3xl">{provider.fullName}</h2>{provider.isVerified === 1 && <BadgeCheck className="h-5 w-5 text-[#9be4ce]" />}</div><p className="text-white/70">{provider.category} · {provider.locationName}</p><div className="mt-3 flex items-center gap-4 text-sm"><span className="flex items-center gap-1.5"><Star className="h-4 w-4 fill-[#f0c265] text-[#f0c265]" /> {provider.ratingAvg}</span><span>{provider.reviewCount} verified reviews</span></div></div></div><Badge className="w-fit border-0 bg-white/10 text-white"><span className={`mr-2 h-2 w-2 rounded-full ${provider.isOnline === 1 ? "bg-[#9be4ce]" : "bg-white/40"}`} />{provider.isOnline === 1 ? "Available now" : "Currently offline"}</Badge></div>
        </div>
        <div className="grid gap-7 p-7 sm:p-9">
          <div className="grid gap-3 sm:grid-cols-3"><div className="info-chip"><Clock3 /><span><small>Experience</small><strong>{provider.experienceYears} years</strong></span></div><div className="info-chip"><CircleDollarIcon /><span><small>Base price</small><strong>{formatINR(provider.basePrice)}</strong></span></div><div className="info-chip"><MapPin /><span><small>Service radius</small><strong>{provider.serviceRadiusKm} km</strong></span></div></div>
          <div><h3 className="section-kicker">About this partner</h3><p className="mt-2 leading-7 text-[#657275]">{provider.bio || "This partner has not added a bio yet. Start a conversation to discuss your service requirement."}</p></div>
          <div><div className="flex items-center justify-between"><h3 className="section-kicker">Past work photos</h3><Badge variant="outline" className="border-[#d9e1de] text-[#2a8a76]">Portfolio</Badge></div>{photos.length ? <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">{photos.map(photo => <img key={photo} src={photo} alt="Partner portfolio" className="aspect-[4/3] w-full rounded-2xl object-cover" />)}</div> : <div className="mt-3 rounded-2xl border border-dashed border-[#d9e1de] bg-[#f6f8f5] p-5 text-sm text-[#738083]">Portfolio images will appear here once this partner uploads past work.</div>}</div>
          <div><h3 className="section-kicker">Verified customer reviews</h3>{isLoading ? <div className="mt-4 flex items-center gap-2 text-sm text-[#738083]"><Loader2 className="h-4 w-4 animate-spin" /> Loading reviews</div> : reviews.length ? <div className="mt-3 grid gap-3">{reviews.map(review => <div key={review.id} className="rounded-2xl bg-white p-4 shadow-sm ring-1 ring-[#ece8e2]"><div className="flex items-center justify-between"><span className="font-medium text-[#173e49]">{review.customerName}</span><span className="flex items-center gap-1 text-sm text-[#a26a20]"><Star className="h-3.5 w-3.5 fill-current" /> {review.rating}/5</span></div><p className="mt-2 text-sm leading-6 text-[#697679]">{review.comment}</p></div>)}</div> : <div className="mt-3 rounded-2xl border border-dashed border-[#d9e1de] bg-[#f6f8f5] p-5 text-sm text-[#738083]">No reviews yet. Completed jobs will unlock verified feedback here.</div>}</div>
          <div className="flex flex-col gap-3 sm:flex-row"><Button onClick={onRequest} className="h-12 flex-1 rounded-xl bg-[#d26c3b] text-white hover:bg-[#bb582b]"><Send className="mr-2 h-4 w-4" /> Request this service</Button><Button variant="outline" className="h-12 flex-1 rounded-xl border-[#ccd9d5] text-[#173e49]" onClick={() => toast.info("Direct messaging is ready for the next marketplace release.")}><MessageCircle className="mr-2 h-4 w-4" /> Message partner</Button><Button asChild variant="outline" className="h-12 rounded-xl border-[#ccd9d5] text-[#173e49]"><a href={`tel:${provider.phone || ""}`}><Phone className="mr-2 h-4 w-4" /> Call</a></Button><Button asChild variant="outline" className="h-12 rounded-xl border-[#ccd9d5] text-[#173e49]"><a href={`https://wa.me/${(provider.phone || "").replace(/\\D/g, "")}`} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" /> WhatsApp</a></Button></div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function CircleDollarIcon() { return <span className="flex h-5 w-5 items-center justify-center rounded-full border-2 border-current text-xs font-bold">₹</span>; }

function Home() {
  const { user, loading: authLoading, isAuthenticated, logout } = useAuth();
  const [authOpen, setAuthOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<RoleChoice>("customer");
  const [profileOpen, setProfileOpen] = useState(false);
  const [jobOpen, setJobOpen] = useState(false);
  const [provider, setProvider] = useState<Provider | null>(null);
  const [providerOpen, setProviderOpen] = useState(false);
  const [dashboardOpen, setDashboardOpen] = useState(false);
  const [reviewJob, setReviewJob] = useState<{ id: number; assignedPartnerId: number | null; title: string } | null>(null);
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: "" });
  const [reviewedJobIds, setReviewedJobIds] = useState<number[]>([]);
  const [geo, setGeo] = useState<{ latitude: number; longitude: number } | null>(null);
  const [category, setCategory] = useState("All services");
  const [location, setLocation] = useState("New Delhi");
  const [search, setSearch] = useState("");
  const syncedRole = useRef(false);

  const providerQuery = useMemo(() => ({ category: category === "All services" ? undefined : category, location: geo ? undefined : (search.trim() || location.trim() || undefined), latitude: geo?.latitude, longitude: geo?.longitude, radiusKm: 25 }), [category, location, search, geo]);
  const { data: providers = [], isLoading: providersLoading } = trpc.providers.list.useQuery(providerQuery);
  const { data: partnerProfile, isLoading: profileLoading } = trpc.partner.me.useQuery(undefined, { enabled: isAuthenticated });
  const { data: incomingJobs = [], isLoading: incomingLoading } = trpc.partner.incomingJobs.useQuery(undefined, { enabled: isAuthenticated && user?.marketplaceRole === "service_partner" });
  const { data: customerJobs = [], isLoading: customerJobsLoading } = trpc.jobs.mine.useQuery(undefined, { enabled: isAuthenticated && user?.marketplaceRole !== "service_partner" });
  const setRole = trpc.auth.setMarketplaceRole.useMutation();
  const saveProfile = trpc.partner.saveProfile.useMutation();
  const toggleAvailability = trpc.partner.toggleAvailability.useMutation();
  const createJob = trpc.jobs.create.useMutation();
  const respondToJob = trpc.jobs.respond.useMutation();
  const completeJob = trpc.jobs.complete.useMutation();
  const createReview = trpc.reviews.create.useMutation();

  const [profileForm, setProfileForm] = useState({ fullName: "", category: "Plumber", bio: "", experienceYears: 1, basePrice: 500, serviceRadiusKm: 5, locationName: "New Delhi, India", phone: "", photoUrl: "", pastWorkPhotos: "" });
  const [jobForm, setJobForm] = useState({ customerName: "", customerPhone: "", category: "Plumber", title: "", description: "", location: "", budget: "" });

  const requestLocation = () => {
    if (!navigator.geolocation) { toast.error("Location is not available in this browser."); return; }
    navigator.geolocation.getCurrentPosition(
      position => { setGeo({ latitude: position.coords.latitude, longitude: position.coords.longitude }); setLocation("Nearby you"); toast.success("Showing partners within 25 km of your location."); },
      () => toast.error("We could not access your location. You can search by area instead."),
      { enableHighAccuracy: false, timeout: 8000 },
    );
  };

  useEffect(() => {
    if (!partnerProfile) return;
    setProfileForm({ fullName: partnerProfile.fullName, category: partnerProfile.category, bio: partnerProfile.bio || "", experienceYears: partnerProfile.experienceYears, basePrice: partnerProfile.basePrice, serviceRadiusKm: partnerProfile.serviceRadiusKm, locationName: partnerProfile.locationName, phone: partnerProfile.phone || "", photoUrl: partnerProfile.photoUrl || "", pastWorkPhotos: partnerProfile.pastWorkPhotos ? (JSON.parse(partnerProfile.pastWorkPhotos) as string[]).join(", ") : "" });
  }, [partnerProfile]);

  useEffect(() => {
    const requestCategory = new URLSearchParams(window.location.search).get("requestCategory");
    if (requestCategory) {
      setJobForm(form => ({ ...form, category: requestCategory, title: `Request for ${requestCategory}`, location }));
      if (isAuthenticated) setJobOpen(true);
      window.history.replaceState({}, "", "/");
    }
  }, [isAuthenticated, location]);

  useEffect(() => {
    if (!isAuthenticated || !user || syncedRole.current) return;
    const intendedRole = window.localStorage.getItem("gullyexpert-intended-role") as RoleChoice | null;
    if (intendedRole && user.marketplaceRole !== intendedRole) {
      syncedRole.current = true;
      setRole.mutate({ marketplaceRole: intendedRole }, { onSuccess: () => { window.localStorage.removeItem("gullyexpert-intended-role"); setAuthOpen(false); if (intendedRole === "service_partner") setProfileOpen(true); toast.success(`Signed in as ${intendedRole === "service_partner" ? "Service Partner" : "Customer"}`); } });
    }
  }, [isAuthenticated, setRole, user]);

  const openLogin = (role: RoleChoice = "customer") => { setSelectedRole(role); setAuthOpen(true); };
  const handleContinue = () => { window.localStorage.setItem("gullyexpert-intended-role", selectedRole); startLogin(); };
  const requireCustomer = (action: () => void) => { if (!isAuthenticated) { openLogin("customer"); return; } action(); };
  const handlePostJob = () => requireCustomer(() => { setJobForm(form => ({ ...form, customerName: user?.name || "", location: location })); setJobOpen(true); });
  const handleProfileSave = () => {
    saveProfile.mutate({ ...profileForm, photoUrl: profileForm.photoUrl || undefined, phone: profileForm.phone, pastWorkPhotos: profileForm.pastWorkPhotos.split(",").map(item => item.trim()).filter(Boolean) }, { onSuccess: () => { toast.success("Your partner storefront is live."); setProfileOpen(false); }, onError: error => toast.error(error.message) });
  };
  const handleJobSave = () => {
    createJob.mutate(jobForm, { onSuccess: () => { toast.success("Your request is visible to nearby partners."); setJobOpen(false); }, onError: error => toast.error(error.message) });
  };
  const openProvider = (item: Provider) => { setProvider(item); setProviderOpen(true); };
  const handleRequestFromProfile = () => { setProviderOpen(false); requireCustomer(() => { setJobForm(form => ({ ...form, category: provider?.category || form.category, title: provider ? `Request for ${provider.category}` : form.title, location })); setJobOpen(true); }); };
  const handleReviewSave = () => {
    if (!reviewJob?.assignedPartnerId) return;
    createReview.mutate({ jobId: reviewJob.id, partnerId: reviewJob.assignedPartnerId, rating: reviewForm.rating, comment: reviewForm.comment }, { onSuccess: () => { toast.success("Thanks for sharing verified feedback."); setReviewedJobIds(ids => [...ids, reviewJob.id]); setReviewJob(null); setReviewForm({ rating: 5, comment: "" }); }, onError: error => toast.error(error.message) });
  };
  const scrollToServices = () => document.getElementById("services")?.scrollIntoView({ behavior: "smooth" });

  return (
    <div id="top" className="min-h-screen bg-[#fbfaf7] text-[#173e49]">
      <Header authenticated={isAuthenticated} userName={user?.name} onLogin={openLogin} onDashboard={() => setDashboardOpen(true)} onPostJob={handlePostJob} onLogout={() => logout()} />
      <main>
        <section className="relative overflow-hidden border-b border-[#e9e4dc]">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_76%_22%,rgba(214,238,230,0.9),transparent_29%),radial-gradient(circle_at_10%_15%,rgba(248,226,204,0.68),transparent_24%)]" />
          <div className="relative mx-auto grid max-w-7xl gap-14 px-5 pb-20 pt-16 lg:grid-cols-[1.08fr_0.92fr] lg:px-8 lg:pb-28 lg:pt-24">
            <div className="flex flex-col justify-center">
              <Badge className="mb-6 w-fit gap-2 border-0 bg-[#e2f0eb] px-3 py-1.5 text-[#2a7568]"><Sparkles className="h-3.5 w-3.5" /> Local help, thoughtfully connected</Badge>
              <h1 className="max-w-3xl font-display text-5xl leading-[0.98] tracking-[-0.055em] text-[#173e49] sm:text-6xl lg:text-[5.4rem]">The good kind of help is <span className="text-[#d26c3b]">closer</span> than you think.</h1>
              <p className="mt-7 max-w-xl text-lg leading-8 text-[#677376]">Find skilled people in your neighborhood for the everyday jobs that keep life moving. Clear profiles, real conversations, and a more human way to get things done.</p>
              <div className="mt-9 flex flex-col gap-3 sm:flex-row"><Button onClick={scrollToServices} className="h-12 rounded-xl bg-[#173e49] px-6 text-white shadow-xl shadow-[#173e49]/15 hover:bg-[#245b67]">Explore local experts <ArrowRight className="ml-2 h-4 w-4" /></Button><Button onClick={() => openLogin("service_partner")} variant="outline" className="h-12 rounded-xl border-[#d4d4c9] bg-white/60 px-6 text-[#173e49]">List your service <Plus className="ml-2 h-4 w-4" /></Button></div>
              <div className="mt-12 flex flex-wrap items-center gap-x-8 gap-y-4 text-sm text-[#718083]"><span className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-[#2a8a76]" /> Verified profiles</span><span className="flex items-center gap-2"><MessageCircle className="h-4 w-4 text-[#2a8a76]" /> Direct connection</span><span className="flex items-center gap-2"><MapPin className="h-4 w-4 text-[#2a8a76]" /> Built around your area</span></div>
            </div>
            <div className="relative min-h-[470px] lg:min-h-[540px]">
              <div className="absolute right-0 top-3 h-[78%] w-[82%] rounded-[3rem] bg-[#dfeeea]" />
              <div className="hero-note absolute left-0 top-14 z-10"><span className="note-dot" /><div><p className="text-xs uppercase tracking-[0.16em] text-[#7b8685]">Your neighborhood</p><p className="mt-1 font-display text-2xl text-[#173e49]">has good people.</p></div></div>
              <div className="absolute bottom-3 right-4 z-10 w-[88%] max-w-[490px] rounded-[2rem] border border-white/70 bg-[#fffdf9]/95 p-5 shadow-[0_26px_70px_rgba(25,66,71,0.16)] backdrop-blur sm:p-7">
                <div className="flex items-center justify-between"><div><p className="text-xs uppercase tracking-[0.18em] text-[#8a9695]">Start with a service</p><h2 className="mt-1 font-display text-2xl text-[#173e49]">What do you need today?</h2></div><div className="rounded-2xl bg-[#f9e8dc] p-3 text-[#d26c3b]"><Compass className="h-5 w-5" /></div></div>
                <div className="mt-5 flex items-center gap-2 rounded-xl border border-[#e0e1d9] bg-white px-3"><Search className="h-4 w-4 text-[#82908f]" /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search a skill or service" className="h-12 min-w-0 flex-1 bg-transparent text-sm text-[#173e49] outline-none placeholder:text-[#a1aaa8]" /></div>
                <div className="mt-3 flex items-center gap-2 rounded-xl border border-[#e0e1d9] bg-white px-3"><MapPin className="h-4 w-4 text-[#d26c3b]" /><input value={location} onChange={event => { setGeo(null); setLocation(event.target.value); }} placeholder="Your area or city" className="h-12 min-w-0 flex-1 bg-transparent text-sm text-[#173e49] outline-none placeholder:text-[#a1aaa8]" /><button type="button" onClick={requestLocation} className="rounded-lg p-1.5 text-[#2a8a76] hover:bg-[#eaf4ef]" aria-label="Use current location"><Compass className="h-4 w-4" /></button></div>
                <Button onClick={scrollToServices} className="mt-4 h-12 w-full rounded-xl bg-[#d26c3b] text-white hover:bg-[#bb582b]">Find help nearby <ArrowRight className="ml-2 h-4 w-4" /></Button>
              </div>
              <div className="absolute right-[7%] top-[27%] hidden w-44 rotate-6 rounded-2xl border border-white/80 bg-white p-3 shadow-xl sm:block"><div className="flex items-center gap-2"><div className="h-8 w-8 rounded-xl bg-[#e3f1ec]" /><div><div className="h-2 w-16 rounded-full bg-[#dce6e3]" /><div className="mt-2 h-2 w-10 rounded-full bg-[#edf0ed]" /></div></div><div className="mt-3 h-2 w-24 rounded-full bg-[#e9eeeb]" /><div className="mt-2 h-2 w-14 rounded-full bg-[#e9eeeb]" /></div>
            </div>
          </div>
        </section>

        <section id="services" className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28">
          <div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-end"><div><p className="section-kicker text-[#d26c3b]">Explore the network</p><h2 className="mt-3 max-w-xl font-display text-4xl tracking-[-0.04em] text-[#173e49] sm:text-5xl">Small jobs. Skilled people. Less friction.</h2></div><Button variant="ghost" className="w-fit text-[#2a8a76]" onClick={() => setCategory("All services")}>View all services <ArrowRight className="ml-2 h-4 w-4" /></Button></div>
          <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-7">{CATEGORIES.map(item => { const Icon = item.icon; return <button type="button" key={item.name} onClick={() => setCategory(item.name)} className={`category-tile ${category === item.name ? "category-tile-active" : ""}`}><span className={`category-icon ${accentStyles[item.accent]}`}><Icon className="h-5 w-5" /></span><span>{item.label}</span><ChevronRight className="ml-auto h-4 w-4 opacity-0 transition-opacity group-hover:opacity-100" /></button>; })}</div>
          <div className="mt-16 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="section-kicker text-[#2a8a76]">{location ? `Near ${location}` : "Nearby experts"}</p><h3 className="mt-2 font-display text-3xl tracking-[-0.035em] text-[#173e49]">Meet the people who can help</h3></div><div className="flex items-center gap-3"><Select value={category} onValueChange={setCategory}><SelectTrigger className="w-[170px] rounded-xl border-[#dddcd4] bg-white"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.map(item => <SelectItem key={item.name} value={item.name}>{item.name}</SelectItem>)}</SelectContent></Select><Button variant="outline" className="rounded-xl border-[#dddcd4] bg-white" onClick={requestLocation}><MapPin className="mr-2 h-4 w-4" /> Use my location</Button><Button variant="outline" className="rounded-xl border-[#dddcd4] bg-white" onClick={() => { setSearch(""); setLocation(""); setGeo(null); }}><SlidersHorizontal className="mr-2 h-4 w-4" /> Reset</Button></div></div>
          {providersLoading ? <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"><div className="skeleton-card" /><div className="skeleton-card" /><div className="skeleton-card" /></div> : providers.length ? <div className="mt-7 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{providers.map(item => <ProviderCard key={item.id} provider={item} onOpen={() => openProvider(item)} />)}</div> : <div className="mt-7 rounded-3xl border border-dashed border-[#d8e0dc] bg-[#f5f8f4] px-6 py-14 text-center"><div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#deeee8] text-[#2a8a76]"><Compass className="h-6 w-6" /></div><h4 className="mt-5 font-display text-2xl text-[#173e49]">Your local network is just getting started</h4><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#718083]">No partner profile matches this search yet. Post your request and invite a skilled person in your area to join GullyExpert.</p><Button onClick={handlePostJob} className="mt-6 rounded-xl bg-[#173e49] text-white hover:bg-[#245b67]">Post a request <ArrowUpRight className="ml-2 h-4 w-4" /></Button></div>}
        </section>

        <section id="how-it-works" className="border-y border-[#e9e4dc] bg-[#f3f0ea]">
          <div className="mx-auto grid max-w-7xl gap-12 px-5 py-20 lg:grid-cols-[0.85fr_1.15fr] lg:px-8 lg:py-28"><div><p className="section-kicker text-[#d26c3b]">A calmer way to get things done</p><h2 className="mt-3 font-display text-4xl tracking-[-0.045em] text-[#173e49] sm:text-5xl">Good service should feel simple.</h2><p className="mt-5 max-w-md leading-7 text-[#697679]">From the first search to the final review, GullyExpert keeps the important details visible so customers and partners can work with confidence.</p><Button onClick={handlePostJob} className="mt-8 rounded-xl bg-[#d26c3b] text-white hover:bg-[#bb582b]">Tell us what you need <ArrowRight className="ml-2 h-4 w-4" /></Button></div><div className="grid gap-4 sm:grid-cols-3">{[{number:"01", title:"Describe the job", text:"Share the service, area, and details in a few clear steps.", icon:ClipboardIcon},{number:"02", title:"Compare nearby help", text:"Review partner profiles, availability, pricing, and experience.", icon:Search},{number:"03", title:"Connect with confidence", text:"Choose the right fit, complete the job, and leave verified feedback.", icon:CheckCircle2}].map(step => { const Icon = step.icon; return <div key={step.number} className="step-card"><span className="text-sm font-semibold text-[#d26c3b]">{step.number}</span><Icon className="mt-10 h-6 w-6 text-[#2a8a76]" /><h3 className="mt-5 font-display text-2xl text-[#173e49]">{step.title}</h3><p className="mt-3 text-sm leading-6 text-[#788384]">{step.text}</p></div>; })}</div></div>
        </section>

        <section className="mx-auto max-w-7xl px-5 py-20 lg:px-8 lg:py-28"><div className="grid gap-5 lg:grid-cols-3"><div className="rounded-[2rem] bg-[#173e49] p-8 text-white lg:col-span-2 lg:p-11"><div className="flex max-w-2xl flex-col justify-between gap-12 sm:flex-row"><div><Badge className="border-0 bg-white/10 text-[#b6e2d5]">For service partners</Badge><h2 className="mt-5 font-display text-4xl tracking-[-0.04em] sm:text-5xl">Your work deserves a better storefront.</h2><p className="mt-5 max-w-lg leading-7 text-white/70">Show up with a profile that feels like you. Set your radius, publish your services, manage incoming requests, and stay in control of your availability.</p><Button onClick={() => openLogin("service_partner")} className="mt-8 rounded-xl bg-[#f3c27a] text-[#173e49] hover:bg-[#ffd291]">Become a partner <ArrowUpRight className="ml-2 h-4 w-4" /></Button></div><div className="hidden w-36 shrink-0 self-end rounded-3xl border border-white/10 bg-white/5 p-5 sm:block"><Settings2 className="h-6 w-6 text-[#f3c27a]" /><p className="mt-10 text-sm leading-6 text-white/70">Your profile. Your radius. Your rhythm.</p></div></div></div><div className="rounded-[2rem] bg-[#f7eadb] p-8 lg:p-9"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white text-[#d26c3b]"><Bell className="h-5 w-5" /></div><h3 className="mt-8 font-display text-3xl text-[#173e49]">The local-first advantage</h3><p className="mt-4 leading-7 text-[#6f7777]">Fewer tabs. Fewer unknowns. A closer relationship between the person who needs help and the person who knows how to give it.</p></div></div></section>
      </main>
      <footer className="border-t border-[#e9e4dc] bg-[#f6f3ee]"><div className="mx-auto flex max-w-7xl flex-col gap-5 px-5 py-8 text-sm text-[#778083] sm:flex-row sm:items-center sm:justify-between lg:px-8"><div className="flex items-center gap-3"><span className="brand-mark small"><MapPin className="h-4 w-4" /></span><span>GullyExpert — local help, made easier.</span></div><p>Built for neighborhoods, one trusted connection at a time.</p></div></footer>

      <AuthDialog open={authOpen} onOpenChange={setAuthOpen} selectedRole={selectedRole} onSelectedRole={setSelectedRole} onContinue={handleContinue} />
      <ProviderDialog provider={provider} open={providerOpen} onOpenChange={setProviderOpen} onRequest={handleRequestFromProfile} />

      <Dialog open={profileOpen} onOpenChange={setProfileOpen}><DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto border-[#e2ddd5] bg-[#fbfaf7] sm:rounded-3xl"><DialogHeader><Badge className="w-fit border-0 bg-[#e2f0eb] text-[#2a7568]">Partner onboarding</Badge><DialogTitle className="font-display text-3xl text-[#173e49]">Create your digital storefront</DialogTitle><DialogDescription>Make your skills easy to discover. You can edit these details any time.</DialogDescription></DialogHeader><div className="grid gap-4 py-4 sm:grid-cols-2"><div className="sm:col-span-2"><Label>Full name</Label><Input value={profileForm.fullName} onChange={e => setProfileForm({ ...profileForm, fullName: e.target.value })} className="mt-2" placeholder="Your name or business name" /></div><div><Label>Primary category</Label><Select value={profileForm.category} onValueChange={value => setProfileForm({ ...profileForm, category: value })}><SelectTrigger className="mt-2"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.filter(item => item.name !== "All services").map(item => <SelectItem key={item.name} value={item.name}>{item.name}</SelectItem>)}</SelectContent></Select></div><div><Label>Years of experience</Label><Input type="number" min={0} value={profileForm.experienceYears} onChange={e => setProfileForm({ ...profileForm, experienceYears: Number(e.target.value) })} className="mt-2" /></div><div><Label>Base price (₹)</Label><Input type="number" min={0} value={profileForm.basePrice} onChange={e => setProfileForm({ ...profileForm, basePrice: Number(e.target.value) })} className="mt-2" /></div><div><Label>Service radius (km)</Label><Input type="number" min={1} value={profileForm.serviceRadiusKm} onChange={e => setProfileForm({ ...profileForm, serviceRadiusKm: Number(e.target.value) })} className="mt-2" /></div><div><Label>Service area</Label><Input value={profileForm.locationName} onChange={e => setProfileForm({ ...profileForm, locationName: e.target.value })} className="mt-2" placeholder="Neighborhood, city" /></div><div><Label>Contact phone</Label><Input value={profileForm.phone} onChange={e => setProfileForm({ ...profileForm, phone: e.target.value })} className="mt-2" placeholder="+91 ..." /></div><div className="sm:col-span-2"><Label>Profile photo URL</Label><Input value={profileForm.photoUrl} onChange={e => setProfileForm({ ...profileForm, photoUrl: e.target.value })} className="mt-2" placeholder="https://..." /></div><div className="sm:col-span-2"><Label>Past work photo URLs</Label><Input value={profileForm.pastWorkPhotos} onChange={e => setProfileForm({ ...profileForm, pastWorkPhotos: e.target.value })} className="mt-2" placeholder="Paste URLs separated by commas" /></div><div className="sm:col-span-2"><Label>Short bio</Label><Textarea value={profileForm.bio} onChange={e => setProfileForm({ ...profileForm, bio: e.target.value })} className="mt-2" placeholder="Tell customers what you do best" /></div></div><DialogFooter><Button variant="outline" onClick={() => setProfileOpen(false)}>Cancel</Button><Button disabled={saveProfile.isPending || !profileForm.fullName} onClick={handleProfileSave} className="bg-[#173e49] text-white hover:bg-[#245b67]">{saveProfile.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Publish storefront</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={jobOpen} onOpenChange={setJobOpen}><DialogContent className="max-h-[92vh] max-w-2xl overflow-y-auto border-[#e2ddd5] bg-[#fbfaf7] sm:rounded-3xl"><DialogHeader><Badge className="w-fit border-0 bg-[#f9e8dc] text-[#a94f2d]">Customer request</Badge><DialogTitle className="font-display text-3xl text-[#173e49]">What would you like help with?</DialogTitle><DialogDescription>Nearby service partners can review the details and respond.</DialogDescription></DialogHeader><div className="grid gap-4 py-4 sm:grid-cols-2"><div className="sm:col-span-2"><Label>Request title</Label><Input value={jobForm.title} onChange={e => setJobForm({ ...jobForm, title: e.target.value })} className="mt-2" placeholder="e.g. Kitchen tap is leaking" /></div><div><Label>Service category</Label><Select value={jobForm.category} onValueChange={value => setJobForm({ ...jobForm, category: value })}><SelectTrigger className="mt-2"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.filter(item => item.name !== "All services").map(item => <SelectItem key={item.name} value={item.name}>{item.name}</SelectItem>)}</SelectContent></Select></div><div><Label>Budget or price range</Label><Input value={jobForm.budget} onChange={e => setJobForm({ ...jobForm, budget: e.target.value })} className="mt-2" placeholder="e.g. ₹500–₹1,000" /></div><div><Label>Your name</Label><Input value={jobForm.customerName} onChange={e => setJobForm({ ...jobForm, customerName: e.target.value })} className="mt-2" placeholder="Full name" /></div><div><Label>Phone number</Label><Input value={jobForm.customerPhone} onChange={e => setJobForm({ ...jobForm, customerPhone: e.target.value })} className="mt-2" placeholder="For partner follow-up" /></div><div className="sm:col-span-2"><Label>Service location</Label><Input value={jobForm.location} onChange={e => setJobForm({ ...jobForm, location: e.target.value })} className="mt-2" placeholder="Neighborhood, city" /></div><div className="sm:col-span-2"><Label>Describe the job</Label><Textarea value={jobForm.description} onChange={e => setJobForm({ ...jobForm, description: e.target.value })} className="mt-2 min-h-28" placeholder="Add useful details, timing, or constraints" /></div></div><DialogFooter><Button variant="outline" onClick={() => setJobOpen(false)}>Cancel</Button><Button disabled={createJob.isPending} onClick={handleJobSave} className="bg-[#d26c3b] text-white hover:bg-[#bb582b]">{createJob.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Publish request</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={reviewJob !== null} onOpenChange={open => { if (!open) setReviewJob(null); }}><DialogContent className="max-w-lg border-[#e2ddd5] bg-[#fbfaf7] sm:rounded-3xl"><DialogHeader><Badge className="w-fit border-0 bg-[#e2f0eb] text-[#2a7568]">Completed job</Badge><DialogTitle className="font-display text-3xl text-[#173e49]">How did {reviewJob?.title || "the service"} go?</DialogTitle><DialogDescription>Your review is linked to the completed request and helps customers make informed choices.</DialogDescription></DialogHeader><div className="space-y-5 py-4"><div><Label>Rating</Label><div className="mt-3 flex gap-2">{[1, 2, 3, 4, 5].map(value => <button type="button" key={value} onClick={() => setReviewForm(form => ({ ...form, rating: value }))} aria-label={`${value} star rating`} className={`rounded-xl p-2 transition ${value <= reviewForm.rating ? "bg-[#fff1d5] text-[#b3771d]" : "bg-[#f0f3ef] text-[#9da8a5]"}`}><Star className="h-6 w-6 fill-current" /></button>)}</div></div><div><Label>Your experience</Label><Textarea value={reviewForm.comment} onChange={event => setReviewForm(form => ({ ...form, comment: event.target.value }))} className="mt-2 min-h-28" placeholder="What should another customer know?" /></div></div><DialogFooter><Button variant="outline" onClick={() => setReviewJob(null)}>Not now</Button><Button disabled={createReview.isPending || reviewForm.comment.trim().length < 10} onClick={handleReviewSave} className="bg-[#173e49] text-white hover:bg-[#245b67]">{createReview.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Publish review</Button></DialogFooter></DialogContent></Dialog>

      <Dialog open={dashboardOpen} onOpenChange={setDashboardOpen}><DialogContent className="max-h-[92vh] max-w-4xl overflow-y-auto border-[#e2ddd5] bg-[#fbfaf7] sm:rounded-3xl"><DialogHeader><Badge className="w-fit border-0 bg-[#e2f0eb] text-[#2a7568]">Your GullyExpert space</Badge><DialogTitle className="font-display text-3xl text-[#173e49]">{user?.marketplaceRole === "service_partner" ? "Partner desk" : "Your requests"}</DialogTitle><DialogDescription>Keep your profile, availability, and service conversations in one place.</DialogDescription></DialogHeader>{authLoading || profileLoading ? <div className="flex items-center gap-2 py-12 text-sm text-[#738083]"><Loader2 className="h-4 w-4 animate-spin" /> Loading your space</div> : <Tabs defaultValue={user?.marketplaceRole === "service_partner" ? "incoming" : "requests"} className="mt-3"><TabsList className="bg-[#edf2ef]"><TabsTrigger value="requests">My requests</TabsTrigger>{user?.marketplaceRole === "service_partner" && <TabsTrigger value="incoming">Incoming jobs</TabsTrigger>}<TabsTrigger value="profile">My storefront</TabsTrigger></TabsList><TabsContent value="requests" className="mt-5">{customerJobsLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : customerJobs.length ? <div className="grid gap-3">{customerJobs.map(job => <div key={job.id} className="rounded-2xl bg-white p-4 ring-1 ring-[#ebe6df]"><div className="flex flex-col justify-between gap-2 sm:flex-row sm:items-center"><div><p className="font-medium text-[#173e49]">{job.title}</p><p className="mt-1 text-sm text-[#738083]">{job.category} · {job.location}</p></div><Badge variant="outline" className="w-fit capitalize">{job.status}</Badge></div>{(job.status === "assigned" || (job.status === "completed" && job.assignedPartnerId && !reviewedJobIds.includes(job.id))) && <div className="mt-3 flex flex-wrap gap-2">{job.status === "assigned" && <Button size="sm" variant="outline" disabled={completeJob.isPending} onClick={() => completeJob.mutate({ id: job.id }, { onSuccess: () => toast.success("Job marked completed"), onError: error => toast.error(error.message) })} className="rounded-lg">Mark completed</Button>}{job.status === "completed" && job.assignedPartnerId && !reviewedJobIds.includes(job.id) && <Button size="sm" onClick={() => { setReviewJob({ id: job.id, assignedPartnerId: job.assignedPartnerId, title: job.title }); setReviewForm({ rating: 5, comment: "" }); }} className="rounded-lg bg-[#d26c3b] text-white hover:bg-[#bb582b]">Leave review</Button>}</div>}</div>)}</div> : <EmptyDashboard title="No requests yet" text="Tell us what you need and nearby partners can respond." onClick={handlePostJob} button="Post a request" />}</TabsContent>{user?.marketplaceRole === "service_partner" && <TabsContent value="incoming" className="mt-5">{incomingLoading ? <Loader2 className="h-5 w-5 animate-spin" /> : incomingJobs.length ? <div className="grid gap-3">{incomingJobs.map(job => <div key={job.id} className="rounded-2xl bg-white p-4 ring-1 ring-[#ebe6df]"><div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center"><div><p className="font-medium text-[#173e49]">{job.title}</p><p className="mt-1 text-sm text-[#738083]">{job.category} · {job.location} · {job.budget}</p><p className="mt-2 text-sm leading-6 text-[#667174]">{job.description}</p></div><Button disabled={respondToJob.isPending} onClick={() => respondToJob.mutate({ id: job.id }, { onSuccess: () => toast.success("Job accepted") })} className="rounded-xl bg-[#173e49] text-white hover:bg-[#245b67]">Accept job</Button></div></div>)}</div> : <EmptyDashboard title="No nearby jobs yet" text="Keep your availability on and complete your storefront to appear for customers." onClick={() => setProfileOpen(true)} button="Edit storefront" />}</TabsContent>}<TabsContent value="profile" className="mt-5">{partnerProfile ? <div className="rounded-3xl bg-white p-5 ring-1 ring-[#ebe6df]"><div className="flex flex-col justify-between gap-5 sm:flex-row sm:items-center"><div className="flex items-center gap-4"><ProviderAvatar provider={partnerProfile as Provider} /><div><h3 className="font-display text-2xl text-[#173e49]">{partnerProfile.fullName}</h3><p className="text-sm text-[#738083]">{partnerProfile.category} · {partnerProfile.locationName}</p></div></div><div className="flex items-center gap-3 rounded-2xl bg-[#f4f7f4] px-4 py-3"><span className="text-sm text-[#667174]">Available for requests</span><Switch checked={partnerProfile.isOnline === 1} onCheckedChange={value => toggleAvailability.mutate({ isOnline: value }, { onSuccess: () => toast.success(value ? "You are now online" : "You are now offline") })} /></div></div><div className="mt-6 grid gap-3 sm:grid-cols-3"><div className="info-chip"><Star className="h-5 w-5 text-[#d89a32]" /><span><small>Rating</small><strong>{partnerProfile.ratingAvg} · {partnerProfile.reviewCount} reviews</strong></span></div><div className="info-chip"><BriefcaseBusiness className="h-5 w-5 text-[#2a8a76]" /><span><small>Experience</small><strong>{partnerProfile.experienceYears} years</strong></span></div><div className="info-chip"><MapPin className="h-5 w-5 text-[#d26c3b]" /><span><small>Radius</small><strong>{partnerProfile.serviceRadiusKm} km</strong></span></div></div><Button onClick={() => setProfileOpen(true)} variant="outline" className="mt-5 rounded-xl">Edit storefront <Settings2 className="ml-2 h-4 w-4" /></Button></div> : <EmptyDashboard title="Your storefront is not live" text="Add your service details so customers can discover and contact you." onClick={() => setProfileOpen(true)} button="Create storefront" />}</TabsContent></Tabs>}</DialogContent></Dialog>
    </div>
  );
}

function EmptyDashboard({ title, text, onClick, button }: { title: string; text: string; onClick: () => void; button: string }) { return <div className="rounded-3xl border border-dashed border-[#d8e0dc] bg-[#f5f8f4] p-10 text-center"><h3 className="font-display text-2xl text-[#173e49]">{title}</h3><p className="mx-auto mt-2 max-w-md text-sm leading-6 text-[#738083]">{text}</p><Button onClick={onClick} className="mt-5 rounded-xl bg-[#173e49] text-white hover:bg-[#245b67]">{button} <ArrowRight className="ml-2 h-4 w-4" /></Button></div>; }
function ClipboardIcon() { return <ClipboardList className="h-6 w-6" />; }

export default Home;
