import { Link, useRoute } from "wouter";
import { ArrowLeft, BadgeCheck, BriefcaseBusiness, CircleDollarSign, Loader2, MapPin, MessageCircle, Phone, Send, ShieldCheck, Star, Wrench } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";

const formatINR = (value: number) => `₹${value.toLocaleString("en-IN")}`;

export default function ProviderProfile() {
  const [, params] = useRoute("/providers/:id");
  const id = Number(params?.id);
  const { data: provider, isLoading } = trpc.providers.getById.useQuery({ id }, { enabled: Number.isInteger(id) && id > 0 });
  const { data: reviews = [], isLoading: reviewsLoading } = trpc.providers.reviews.useQuery({ partnerId: id }, { enabled: Number.isInteger(id) && id > 0 });

  if (isLoading) return <div className="flex min-h-screen items-center justify-center bg-[#fbfaf7] text-[#2a7568]"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  if (!provider) return <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#fbfaf7] px-6 text-center"><p className="section-kicker text-[#d26c3b]">Profile not found</p><h1 className="font-display text-4xl text-[#173e49]">This storefront is no longer available.</h1><Button asChild className="rounded-xl bg-[#173e49] text-white"><Link href="/">Back to GullyExpert</Link></Button></div>;

  let photos: string[] = [];
  try { photos = provider.pastWorkPhotos ? JSON.parse(provider.pastWorkPhotos) as string[] : []; } catch { photos = []; }
  const phone = provider.phone || "";

  return <div className="min-h-screen bg-[#fbfaf7] text-[#173e49]">
    <header className="border-b border-[#e9e4dc] bg-[#fbfaf7]/95 backdrop-blur"><div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-8"><Link href="/" className="flex items-center gap-3"><span className="brand-mark"><MapPin className="h-5 w-5" /></span><span className="text-[1.15rem] font-semibold tracking-[-0.03em]">Gully<span className="text-[#d26c3b]">Expert</span></span></Link><Button asChild variant="outline" className="rounded-xl border-[#ccd9d5]"><Link href="/"><ArrowLeft className="mr-2 h-4 w-4" /> Explore more experts</Link></Button></div></header>
    <main className="mx-auto max-w-7xl px-5 py-10 lg:px-8 lg:py-16">
      <div className="grid gap-8 lg:grid-cols-[1.1fr_0.9fr]">
        <div>
          <div className="flex flex-wrap items-center gap-2"><Badge className="border-0 bg-[#e3f1ec] text-[#2a7568]">{provider.category}</Badge>{provider.isVerified === 1 ? <Badge className="border-0 bg-[#173e49] text-white"><BadgeCheck className="mr-1.5 h-3.5 w-3.5" /> Verified partner</Badge> : <Badge variant="outline" className="border-[#e3ded4] text-[#8a7771]"><ShieldCheck className="mr-1.5 h-3.5 w-3.5" /> Verification pending</Badge>}</div>
          <h1 className="mt-5 max-w-3xl font-display text-5xl tracking-[-0.05em] sm:text-7xl">Meet {provider.fullName}.</h1>
          <p className="mt-5 max-w-2xl text-lg leading-8 text-[#667477]">{provider.bio || "A local service partner ready to discuss your requirement with clear expectations and a human point of contact."}</p>
          <div className="mt-8 flex flex-wrap gap-3"><Button asChild className="h-12 rounded-xl bg-[#d26c3b] text-white hover:bg-[#bb582b]"><a href={`/?requestCategory=${encodeURIComponent(provider.category)}`}><Send className="mr-2 h-4 w-4" /> Request this service</a></Button>{phone && <><Button asChild variant="outline" className="h-12 rounded-xl border-[#ccd9d5]"><a href={`tel:${phone}`}><Phone className="mr-2 h-4 w-4" /> Call</a></Button><Button asChild variant="outline" className="h-12 rounded-xl border-[#ccd9d5]"><a href={`https://wa.me/${phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer"><MessageCircle className="mr-2 h-4 w-4" /> WhatsApp</a></Button></>}</div>
          <div className="mt-10 grid gap-3 sm:grid-cols-3"><div className="info-chip"><Star className="h-5 w-5 text-[#d89a32]" /><span><small>Rating</small><strong>{provider.reviewCount ? `${provider.ratingAvg} / 5` : "No reviews yet"}</strong></span></div><div className="info-chip"><BriefcaseBusiness className="h-5 w-5 text-[#2a8a76]" /><span><small>Experience</small><strong>{provider.experienceYears} years</strong></span></div><div className="info-chip"><CircleDollarSign className="h-5 w-5 text-[#d26c3b]" /><span><small>Base price</small><strong>{formatINR(provider.basePrice)}</strong></span></div></div>
        </div>
        <div className="relative overflow-hidden rounded-[2rem] bg-[#dceee8] p-5 sm:p-8"><div className="absolute -right-12 -top-12 h-48 w-48 rounded-full bg-[#f5c77e]/50 blur-2xl" /><div className="relative flex min-h-[360px] items-end overflow-hidden rounded-[1.5rem] bg-[#b8d9d1]">{provider.photoUrl ? <img src={provider.photoUrl} alt={provider.fullName} className="absolute inset-0 h-full w-full object-cover" /> : <div className="flex h-full w-full items-center justify-center"><div className="flex h-32 w-32 items-center justify-center rounded-[2rem] bg-[#173e49] font-display text-6xl text-white">{provider.fullName.slice(0, 1).toUpperCase()}</div></div>}<div className="relative m-4 w-[calc(100%-2rem)] rounded-2xl bg-[#fffdf9]/95 p-4 backdrop-blur"><p className="text-xs uppercase tracking-[0.18em] text-[#7b8986]">Serves</p><p className="mt-1 flex items-center gap-2 font-medium text-[#173e49]"><MapPin className="h-4 w-4 text-[#d26c3b]" /> {provider.locationName} · within {provider.serviceRadiusKm} km</p><p className="mt-2 flex items-center gap-2 text-sm text-[#687779]"><Wrench className="h-4 w-4 text-[#2a8a76]" /> {provider.isOnline === 1 ? "Currently accepting requests" : "Currently offline"}</p></div></div></div>
      </div>
      <section className="mt-14 border-t border-[#e9e4dc] pt-12"><div className="flex items-end justify-between gap-4"><div><p className="section-kicker text-[#d26c3b]">Past work</p><h2 className="mt-3 font-display text-4xl tracking-[-0.04em]">A closer look at the craft.</h2></div><Badge variant="outline" className="border-[#d9e1de] text-[#2a8a76]">Portfolio</Badge></div>{photos.length ? <div className="mt-7 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{photos.map(photo => <img key={photo} src={photo} alt={`${provider.fullName} past work`} className="aspect-[4/3] w-full rounded-3xl object-cover shadow-sm" />)}</div> : <div className="mt-7 rounded-3xl border border-dashed border-[#d8e0dc] bg-[#f5f8f4] p-12 text-center text-[#718083]">This partner has not added past work photos yet.</div>}</section>
      <section className="mt-14 border-t border-[#e9e4dc] pt-12"><div className="flex items-end justify-between gap-4"><div><p className="section-kicker text-[#2a8a76]">Verified customer reviews</p><h2 className="mt-3 font-display text-4xl tracking-[-0.04em]">What customers say.</h2></div><span className="flex items-center gap-1 text-[#a26a20]"><Star className="h-4 w-4 fill-current" /> {provider.ratingAvg}</span></div>{reviewsLoading ? <div className="mt-7 flex items-center gap-2 text-sm text-[#718083]"><Loader2 className="h-4 w-4 animate-spin" /> Loading reviews</div> : reviews.length ? <div className="mt-7 grid gap-4 md:grid-cols-2">{reviews.map(review => <Card key={review.id} className="border-0 bg-white shadow-sm ring-1 ring-[#ebe6df]"><CardContent className="p-5"><div className="flex items-center justify-between"><span className="font-medium">{review.customerName}</span><span className="flex items-center gap-1 text-sm text-[#a26a20]"><Star className="h-3.5 w-3.5 fill-current" /> {review.rating}/5</span></div><p className="mt-3 leading-7 text-[#687779]">{review.comment}</p></CardContent></Card>)}</div> : <div className="mt-7 rounded-3xl border border-dashed border-[#d8e0dc] bg-[#f5f8f4] p-12 text-center text-[#718083]">No verified reviews yet. Completed jobs will unlock feedback here.</div>}</section>
    </main>
  </div>;
}
